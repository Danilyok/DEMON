﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data;

namespace DEMON
{
    public class DataBase
    {
        private readonly string connectionString;

        public DataBase(string connectionString)
        {
            this.connectionString = connectionString ?? throw new ArgumentNullException(nameof(connectionString));
        }

        public string GetUserRole(string login, string password)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                string query = @"
                SELECT R.Название 
                FROM Пользователи U
                JOIN Роли R ON U.FK_Роли = R.ID_Роли
                WHERE U.Логин = @Login AND U.Пароль = @Password";

                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@Login", login);
                command.Parameters.AddWithValue("@Password", password);

                object role = command.ExecuteScalar();
                return role?.ToString(); // Возвращает роль или null, если пользователь не найден
            }
        }

        public int GetUserId(string login, string password)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                string query = @"
                SELECT ID_Пользователя 
                FROM Пользователи 
                WHERE Логин = @Login AND Пароль = @Password";

                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@Login", login);
                command.Parameters.AddWithValue("@Password", password);

                object result = command.ExecuteScalar();
                return result != null ? Convert.ToInt32(result) : -1;
            }
        }

        public bool AddRequest(string видОргтехники, string модель, string описаниеПроблемы, int fkЗаказчика)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                string query = @"
                INSERT INTO Заявки (Дата_добавления, Вид_оргтехники, Модель, Описание_проблемы, Статус_заявки, FK_Заказчика)
                VALUES (@ДатаДобавления, @ВидОргтехники, @Модель, @ОписаниеПроблемы, @СтатусЗаявки, @FK_Заказчика)";

                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@ДатаДобавления", DateTime.Now);
                command.Parameters.AddWithValue("@ВидОргтехники", видОргтехники);
                command.Parameters.AddWithValue("@Модель", модель);
                command.Parameters.AddWithValue("@ОписаниеПроблемы", описаниеПроблемы);
                command.Parameters.AddWithValue("@СтатусЗаявки", "Новая");
                command.Parameters.AddWithValue("@FK_Заказчика", fkЗаказчика);

                return command.ExecuteNonQuery() > 0;
            }
        }

        public DataTable GetRequests(int? customerId = null)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                string query = @"
            SELECT 
                z.ID_Заявки, 
                z.Дата_добавления, 
                z.Вид_оргтехники, 
                z.Модель, 
                z.Описание_проблемы, 
                z.Статус_заявки, 
                z.Дата_окончания,
                p.Название AS Запчасть,
                u.ФИО AS Мастер,
                c.ФИО AS Заказчик
            FROM Заявки z
            LEFT JOIN Запчасти p ON z.FK_Запчасти = p.ID_Запчасти
            LEFT JOIN Пользователи u ON z.FK_Мастера = u.ID_Пользователя
            LEFT JOIN Пользователи c ON z.FK_Заказчика = c.ID_Пользователя";

                if (customerId.HasValue)
                {
                    query += " WHERE z.FK_Заказчика = @CustomerId";
                }

                SqlDataAdapter adapter = new SqlDataAdapter(query, connection);

                if (customerId.HasValue)
                {
                    adapter.SelectCommand.Parameters.AddWithValue("@CustomerId", customerId.Value);
                }

                DataTable requestsTable = new DataTable();
                adapter.Fill(requestsTable);
                return requestsTable;
            }
        }

        public DataRow GetRequestById(int requestId)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                string query = @"
            SELECT ID_Заявки, Статус_заявки, Дата_окончания, FK_Запчасти, FK_Мастера
            FROM Заявки
            WHERE ID_Заявки = @RequestId";

                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@RequestId", requestId);

                SqlDataAdapter adapter = new SqlDataAdapter(command);
                DataTable dataTable = new DataTable();
                adapter.Fill(dataTable);

                return dataTable.Rows.Count > 0 ? dataTable.Rows[0] : null;
            }
        }

        public bool UpdateRequest(int requestId, string status, DateTime endDate, int partId, int masterId)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                string query = @"
            UPDATE Заявки
            SET 
                Статус_заявки = @Status,
                Дата_окончания = @EndDate,
                FK_Запчасти = @PartId,
                FK_Мастера = @MasterId
            WHERE ID_Заявки = @RequestId";

                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@Status", status);
                command.Parameters.AddWithValue("@EndDate", endDate);
                command.Parameters.AddWithValue("@PartId", partId);
                command.Parameters.AddWithValue("@MasterId", masterId);
                command.Parameters.AddWithValue("@RequestId", requestId);

                return command.ExecuteNonQuery() > 0;
            }
        }

        public DataTable GetParts()
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                string query = "SELECT ID_Запчасти, Название FROM Запчасти";
                SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                DataTable partsTable = new DataTable();
                adapter.Fill(partsTable);
                return partsTable;
            }
        }

        // Метод для получения списка мастеров
        public DataTable GetMasters()
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                string query = @"
            SELECT u.ID_Пользователя, u.ФИО
            FROM Пользователи u
            INNER JOIN Роли r ON u.FK_Роли = r.ID_Роли
            WHERE r.Название = 'Мастер'";

                SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                DataTable mastersTable = new DataTable();
                adapter.Fill(mastersTable);
                return mastersTable;
            }
        }
    }
}
