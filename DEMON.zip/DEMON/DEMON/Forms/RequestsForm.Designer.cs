﻿
namespace DEMON.Forms
{
    partial class RequestsForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.iDЗаявкиDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.датадобавленияDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.видоргтехникиDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.модельDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.описаниепроблемыDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.статусзаявкиDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.датаокончанияDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.fKЗапчастиDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.fKМастераDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.fKЗаказчикаDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.заявкиBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.varikDataSet = new DEMON.VarikDataSet();
            this.заявкиTableAdapter = new DEMON.VarikDataSetTableAdapters.ЗаявкиTableAdapter();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.buttonEdit = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.заявкиBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.varikDataSet)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.iDЗаявкиDataGridViewTextBoxColumn,
            this.датадобавленияDataGridViewTextBoxColumn,
            this.видоргтехникиDataGridViewTextBoxColumn,
            this.модельDataGridViewTextBoxColumn,
            this.описаниепроблемыDataGridViewTextBoxColumn,
            this.статусзаявкиDataGridViewTextBoxColumn,
            this.датаокончанияDataGridViewTextBoxColumn,
            this.fKЗапчастиDataGridViewTextBoxColumn,
            this.fKМастераDataGridViewTextBoxColumn,
            this.fKЗаказчикаDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.заявкиBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(12, 45);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new System.Drawing.Size(776, 310);
            this.dataGridView1.TabIndex = 0;
            // 
            // iDЗаявкиDataGridViewTextBoxColumn
            // 
            this.iDЗаявкиDataGridViewTextBoxColumn.DataPropertyName = "ID_Заявки";
            this.iDЗаявкиDataGridViewTextBoxColumn.HeaderText = "ID_Заявки";
            this.iDЗаявкиDataGridViewTextBoxColumn.Name = "ID_Заявки";
            this.iDЗаявкиDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // датадобавленияDataGridViewTextBoxColumn
            // 
            this.датадобавленияDataGridViewTextBoxColumn.DataPropertyName = "Дата_добавления";
            this.датадобавленияDataGridViewTextBoxColumn.HeaderText = "Дата_добавления";
            this.датадобавленияDataGridViewTextBoxColumn.Name = "датадобавленияDataGridViewTextBoxColumn";
            // 
            // видоргтехникиDataGridViewTextBoxColumn
            // 
            this.видоргтехникиDataGridViewTextBoxColumn.DataPropertyName = "Вид_оргтехники";
            this.видоргтехникиDataGridViewTextBoxColumn.HeaderText = "Вид_оргтехники";
            this.видоргтехникиDataGridViewTextBoxColumn.Name = "видоргтехникиDataGridViewTextBoxColumn";
            // 
            // модельDataGridViewTextBoxColumn
            // 
            this.модельDataGridViewTextBoxColumn.DataPropertyName = "Модель";
            this.модельDataGridViewTextBoxColumn.HeaderText = "Модель";
            this.модельDataGridViewTextBoxColumn.Name = "модельDataGridViewTextBoxColumn";
            // 
            // описаниепроблемыDataGridViewTextBoxColumn
            // 
            this.описаниепроблемыDataGridViewTextBoxColumn.DataPropertyName = "Описание_проблемы";
            this.описаниепроблемыDataGridViewTextBoxColumn.HeaderText = "Описание_проблемы";
            this.описаниепроблемыDataGridViewTextBoxColumn.Name = "описаниепроблемыDataGridViewTextBoxColumn";
            // 
            // статусзаявкиDataGridViewTextBoxColumn
            // 
            this.статусзаявкиDataGridViewTextBoxColumn.DataPropertyName = "Статус_заявки";
            this.статусзаявкиDataGridViewTextBoxColumn.HeaderText = "Статус_заявки";
            this.статусзаявкиDataGridViewTextBoxColumn.Name = "статусзаявкиDataGridViewTextBoxColumn";
            // 
            // датаокончанияDataGridViewTextBoxColumn
            // 
            this.датаокончанияDataGridViewTextBoxColumn.DataPropertyName = "Дата_окончания";
            this.датаокончанияDataGridViewTextBoxColumn.HeaderText = "Дата_окончания";
            this.датаокончанияDataGridViewTextBoxColumn.Name = "датаокончанияDataGridViewTextBoxColumn";
            // 
            // fKЗапчастиDataGridViewTextBoxColumn
            // 
            this.fKЗапчастиDataGridViewTextBoxColumn.DataPropertyName = "FK_Запчасти";
            this.fKЗапчастиDataGridViewTextBoxColumn.HeaderText = "FK_Запчасти";
            this.fKЗапчастиDataGridViewTextBoxColumn.Name = "fKЗапчастиDataGridViewTextBoxColumn";
            // 
            // fKМастераDataGridViewTextBoxColumn
            // 
            this.fKМастераDataGridViewTextBoxColumn.DataPropertyName = "FK_Мастера";
            this.fKМастераDataGridViewTextBoxColumn.HeaderText = "FK_Мастера";
            this.fKМастераDataGridViewTextBoxColumn.Name = "fKМастераDataGridViewTextBoxColumn";
            // 
            // fKЗаказчикаDataGridViewTextBoxColumn
            // 
            this.fKЗаказчикаDataGridViewTextBoxColumn.DataPropertyName = "FK_Заказчика";
            this.fKЗаказчикаDataGridViewTextBoxColumn.HeaderText = "FK_Заказчика";
            this.fKЗаказчикаDataGridViewTextBoxColumn.Name = "fKЗаказчикаDataGridViewTextBoxColumn";
            // 
            // заявкиBindingSource
            // 
            this.заявкиBindingSource.DataMember = "Заявки";
            this.заявкиBindingSource.DataSource = this.varikDataSet;
            // 
            // varikDataSet
            // 
            this.varikDataSet.DataSetName = "VarikDataSet";
            this.varikDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // заявкиTableAdapter
            // 
            this.заявкиTableAdapter.ClearBeforeFill = true;
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button1.Location = new System.Drawing.Point(151, 374);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(105, 33);
            this.button1.TabIndex = 1;
            this.button1.Text = "Добавить";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button2.Location = new System.Drawing.Point(12, 375);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(101, 32);
            this.button2.TabIndex = 2;
            this.button2.Text = "Выйти";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // buttonEdit
            // 
            this.buttonEdit.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonEdit.Location = new System.Drawing.Point(297, 374);
            this.buttonEdit.Name = "buttonEdit";
            this.buttonEdit.Size = new System.Drawing.Size(101, 32);
            this.buttonEdit.TabIndex = 3;
            this.buttonEdit.Text = "Изменить";
            this.buttonEdit.UseVisualStyleBackColor = true;
            this.buttonEdit.Click += new System.EventHandler(this.buttonEdit_Click);
            // 
            // RequestsForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.buttonEdit);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.dataGridView1);
            this.Name = "RequestsForm";
            this.Text = "RequestsForm";
            this.Load += new System.EventHandler(this.RequestsForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.заявкиBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.varikDataSet)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private VarikDataSet varikDataSet;
        private System.Windows.Forms.BindingSource заявкиBindingSource;
        private VarikDataSetTableAdapters.ЗаявкиTableAdapter заявкиTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn iDЗаявкиDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn датадобавленияDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn видоргтехникиDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn модельDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn описаниепроблемыDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn статусзаявкиDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn датаокончанияDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn fKЗапчастиDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn fKМастераDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn fKЗаказчикаDataGridViewTextBoxColumn;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button buttonEdit;
    }
}