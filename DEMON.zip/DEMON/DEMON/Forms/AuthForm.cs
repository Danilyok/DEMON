﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DEMON.Forms
{
    public partial class AuthForm : Form
    {
        private readonly DataBase db;

        public AuthForm()
        {
            InitializeComponent();
            db = new DataBase("Server=LAPTOP-VF6RUNDD;Database=Varik;Integrated Security=True;");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string login = txtLogin.Text.Trim();
            string password = txtPassword.Text.Trim();

            if (string.IsNullOrEmpty(login) || string.IsNullOrEmpty(password))
            {
                MessageBox.Show("Введите логин и пароль.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                string userRole = db.GetUserRole(login, password);
                int userId = db.GetUserId(login, password);

                if (!string.IsNullOrEmpty(userRole))
                {
                    MessageBox.Show($"Ваша роль: {userRole}", "Информация", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    RequestsForm requestsForm = new RequestsForm(userRole, userId, db);
                    requestsForm.Show();
                    this.Hide();
                }
                else
                {
                    MessageBox.Show("Неверный логин или пароль.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}

