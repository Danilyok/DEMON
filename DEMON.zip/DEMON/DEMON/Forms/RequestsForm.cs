﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DEMON.Forms
{
    public partial class RequestsForm : Form
    {
        private readonly string currentRole;
        private readonly int currentUserId;
        private readonly DataBase db;

        public RequestsForm(string role, int userId, DataBase database)
        {
            InitializeComponent();
            currentRole = role;
            currentUserId = userId;
            db = database;

            button1.Visible = currentRole == "Заказчик";
            buttonEdit.Visible = currentRole == "Менеджер" || currentRole == "Оператор"; // Редактировать заявку
        }

        private void RequestsForm_Load(object sender, EventArgs e)
        {
            RefreshRequests();
            buttonEdit.Visible = currentRole == "Менеджер" || currentRole == "Оператор";
        }

        private void RefreshRequests()
        {
            try
            {
                // Извлекаем данные из базы данных
                var requests = db.GetRequests(currentRole == "Заказчик" ? currentUserId : (int?)null);

                // Привязываем данные к DataGridView
                dataGridView1.DataSource = null; // Очищаем старую привязку
                dataGridView1.DataSource = requests; // Привязываем обновленные данные

                dataGridView1.Refresh(); // Принудительно обновляем отображение
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки данных: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            AddForm addForm = new AddForm(db, currentUserId);

            if (addForm.ShowDialog() == DialogResult.OK)
            {
                RefreshRequests();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void buttonEdit_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count == 0)
            {
                MessageBox.Show("Пожалуйста, выберите заявку для редактирования.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            int requestId = Convert.ToInt32(dataGridView1.SelectedRows[0].Cells["ID_Заявки"].Value);

            EditForm editForm = new EditForm(db, requestId);
            if (editForm.ShowDialog() == DialogResult.OK)
            {
                RefreshRequests(); // Обновляем данные в DataGridView
            }
        }
    }
}
