﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DEMON.Forms
{
    public partial class AddForm : Form
    {
        private DataBase db;
        private int customerId;

        public AddForm(DataBase database, int userId)
        {
            InitializeComponent();
            db = database;
            customerId = userId;
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            string видОргтехники = txtDeviceType.Text.Trim();
            string модель = txtModel.Text.Trim();
            string описаниеПроблемы = txtDescription.Text.Trim();

            if (string.IsNullOrEmpty(видОргтехники) || string.IsNullOrEmpty(модель) || string.IsNullOrEmpty(описаниеПроблемы))
            {
                MessageBox.Show("Все поля должны быть заполнены.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                bool result = db.AddRequest(видОргтехники, модель, описаниеПроблемы, customerId);
                if (result)
                {
                    MessageBox.Show("Заявка успешно добавлена.", "Успех", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    // Устанавливаем DialogResult для возврата OK
                    this.DialogResult = DialogResult.OK;
                    this.Close();
                }
                else
                {
                    MessageBox.Show("Ошибка при добавлении заявки.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
