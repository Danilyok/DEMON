﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DEMON.Forms
{
    public partial class EditForm : Form
    {
        private readonly DataBase db;
        private readonly int requestId;

        public EditForm(DataBase database, int requestId)
        {
            InitializeComponent();
            db = database;
            this.requestId = requestId;

            LoadComboBoxData();
            LoadRequestData(); // Загрузка данных для редактирования
        }

        private void LoadRequestData()
        {
            try
            {
                var requestData = db.GetRequestById(requestId);
                if (requestData == null)
                {
                    MessageBox.Show("Заявка не найдена.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    Close();
                    return;
                }

                // Заполняем поля формы данными из базы
                txtStatus.Text = requestData["Статус_заявки"].ToString();
                datePickerEndDate.Value = requestData["Дата_окончания"] != DBNull.Value
                    ? Convert.ToDateTime(requestData["Дата_окончания"])
                    : DateTime.Now;
                cmbParts.SelectedValue = requestData["FK_Запчасти"];
                cmbMasters.SelectedValue = requestData["FK_Мастера"];
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки данных: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Close();
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                bool result = db.UpdateRequest(
                    requestId,
                    txtStatus.Text.Trim(),
                    datePickerEndDate.Value,
                    (int)cmbParts.SelectedValue,
                    (int)cmbMasters.SelectedValue
                );

                if (result)
                {
                    MessageBox.Show("Заявка успешно обновлена!", "Успех", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    DialogResult = DialogResult.OK; // Устанавливаем результат диалога
                }
                else
                {
                    MessageBox.Show("Не удалось обновить заявку.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void LoadComboBoxData()
        {
            try
            {
                // Загружаем данные запчастей
                DataTable parts = db.GetParts();
                if (parts.Rows.Count > 0)
                {
                    cmbParts.DataSource = parts;
                    cmbParts.DisplayMember = "Название"; // Название запчасти
                    cmbParts.ValueMember = "ID_Запчасти"; // ID запчасти
                    cmbParts.SelectedIndex = -1; // По умолчанию ничего не выбрано
                }

                // Загружаем данные мастеров
                DataTable masters = db.GetMasters();
                if (masters.Rows.Count > 0)
                {
                    cmbMasters.DataSource = masters;
                    cmbMasters.DisplayMember = "ФИО"; // Отображаем ФИО мастера
                    cmbMasters.ValueMember = "ID_Пользователя"; // ID мастера
                    cmbMasters.SelectedIndex = -1; // По умолчанию ничего не выбрано
                }
                else
                {
                    MessageBox.Show("Мастеров не найдено.", "Внимание", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки данных: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}

